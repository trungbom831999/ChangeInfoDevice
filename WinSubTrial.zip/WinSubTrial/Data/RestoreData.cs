﻿namespace WinSubTrial
{
    public class RestoreData
    {
        public string Name { get; set; }
        public string Size { get; set; }
        public string Folder { get; set; }
        public string Date { get; set; }
    }
}