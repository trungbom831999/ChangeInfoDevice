﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSubTrial.Enum
{
    static class EnumNET
    {
        public static string NET1 = "";
        public static string NET2 = "";
        //public static string NET1 = "103.189.202.180";
        //public static string NET2 = "103.226.248.208:805";
    }

    static class EnumBrandApp
    {
        public static string snapchat = "SN";
        public static string bigo = "B";
        public static string tinder = "TI";
        public static string chamet = "CH";
        public static string camscanner = "CA";
        public static string telegram = "TE";
        public static string globalsmart = "RD";
    }

    static class EnumPassword
    {
        public static string passwordDefault = "Zxcv123123";
    }
}
