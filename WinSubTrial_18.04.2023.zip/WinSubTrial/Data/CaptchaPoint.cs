﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSubTrial
{

    public class CaptchaPoint
    {
        public string x1 { get; set; }
        public string y1 { get; set; }
        public string x2 { get; set; }

        public string y2 { get; set; }

    }
}
