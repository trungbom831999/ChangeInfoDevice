﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSubTrial
{
    public class Configs
    {
        public string Brand;
        public string SDK;
        public string Country;
        public string Network;
    }
}
