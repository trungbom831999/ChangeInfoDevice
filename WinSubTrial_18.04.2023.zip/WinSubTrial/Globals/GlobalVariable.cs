﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSubTrial.Globals
{
    public static class GlobalVariable
    {
        public static bool isGetPhonenumber = false;
    }
}
