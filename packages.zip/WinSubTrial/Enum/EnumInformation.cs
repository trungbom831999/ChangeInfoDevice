﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSubTrial.Enum
{
    static class EnumInformation
    {
        public static string urlGetCodeApi = "103.133.104.21";

    }
}
